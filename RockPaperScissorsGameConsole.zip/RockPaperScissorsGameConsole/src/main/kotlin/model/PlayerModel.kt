package model

class PlayerModel {
    lateinit var hero: String
}