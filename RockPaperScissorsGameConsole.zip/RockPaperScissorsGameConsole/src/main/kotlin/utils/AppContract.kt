package utils

interface AppContract {
    fun start()
    fun printHeader()
    fun printMenu(player: Int)
}